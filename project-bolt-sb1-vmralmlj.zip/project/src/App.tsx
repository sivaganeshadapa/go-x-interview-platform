import React, { useState } from 'react';
import Homepage from './components/Homepage';
import InterviewDashboard from './components/InterviewDashboard';

function App() {
  const [currentView, setCurrentView] = useState<'homepage' | 'dashboard'>('homepage');

  // For demo purposes, you can toggle between views
  // In a real app, this would be handled by routing
  
  return (
    <div className="App">
      {currentView === 'homepage' ? (
        <div>
          <Homepage />
          {/* Demo navigation - remove in production */}
          <div className="fixed bottom-4 right-4 z-50">
            <button
              onClick={() => setCurrentView('dashboard')}
              className="bg-[#7C4DFF] text-white px-4 py-2 rounded-lg shadow-lg hover:bg-[#6B3FF0] transition-colors"
            >
              View Dashboard Demo
            </button>
          </div>
        </div>
      ) : (
        <div>
          <InterviewDashboard />
          {/* Demo navigation - remove in production */}
          <div className="fixed bottom-4 right-4 z-50">
            <button
              onClick={() => setCurrentView('homepage')}
              className="bg-[#00C2A0] text-white px-4 py-2 rounded-lg shadow-lg hover:bg-[#00B395] transition-colors"
            >
              Back to Homepage
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;