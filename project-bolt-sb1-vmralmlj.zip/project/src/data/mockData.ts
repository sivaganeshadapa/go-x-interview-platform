import { Meeting, Speaker } from '../types';

export const mockSpeakers: Speaker[] = [
  { id: 'zai', name: 'Zai', color: '#10B981', percentage: 42.70 },
  { id: 'siva', name: 'Siva', color: '#EF4444', percentage: 57.30 }
];

export const mockMeeting: Meeting = {
  id: 'siva-interview-001',
  title: 'Siva-interview',
  date: '12 May 2025',
  time: '7:15 PM',
  duration: '20 min',
  type: 'interview',
  participants: mockSpeakers,
  speakerSegments: [
    { speaker: 'zai', startTime: 0, endTime: 120, duration: 120 },
    { speaker: 'siva', startTime: 120, endTime: 300, duration: 180 },
    { speaker: 'zai', startTime: 300, endTime: 480, duration: 180 },
    { speaker: 'siva', startTime: 480, endTime: 720, duration: 240 },
    { speaker: 'zai', startTime: 720, endTime: 1000, duration: 280 },
    { speaker: 'siva', startTime: 1000, endTime: 1200, duration: 200 },
  ],
  audioMetrics: {
    overallScore: 70,
    lipSync: 100,
    engagement: 70,
    influence: 65,
    truthfulness: 65,
    bias: 15,
    sentiment: 75,
    speakingRate: 159,
    fillerWords: ['like', 'uh', 'yeah']
  },
  healthMetrics: {
    heartRate: {
      value: 63,
      unit: 'bpm',
      normalRange: '60-100 bpm',
      trend: [65, 62, 64, 63, 61, 63, 64]
    },
    heartRateVariability: {
      value: 94,
      unit: 'ms',
      normalRange: '19-75 ms',
      trend: [92, 95, 93, 94, 96, 94, 93]
    },
    bloodPressure: {
      systolic: 109,
      diastolic: 70,
      unit: 'mmHg',
      normalRange: 'SBP 90-120 bpm / DBP 60-84 bpm'
    },
    spO2: {
      value: 99,
      unit: '%',
      normalRange: '98-100 %'
    },
    stressIndex: {
      value: 1,
      normalRange: '0 - 4'
    },
    respiration: {
      value: 4,
      unit: 'Br/Pm',
      normalRange: '12-20 Br/Pm'
    }
  },
  biometricVerification: {
    candidateEmail: 'siva.kumar@gmail.com',
    isVerified: true,
    verificationItems: {
      livenessDetection: true,
      expressionAnalysis: true,
      voicePatternMatch: true,
      speechPattern: true
    },
    insights: ['Natural facial movements were detected successfully.']
  },
  hrInsights: {
    candidateAnalysis: {
      overallScore: 75,
      recommendation: 'Recommended',
      technicalScore: {
        value: 7.5,
        maxValue: 10,
        rating: 'Good'
      },
      insights: [
        {
          text: 'Demonstrates understanding of the importance of user research in UI/UX design.',
          tags: ['UI/UX Design', 'User Research']
        },
        {
          text: 'Familiar with Figma and its collaborative features.',
          tags: ['Figma']
        },
        {
          text: 'Emphasizes ease of use and accessibility in design.',
          tags: ['UI/UX Design', 'User Research', 'Figma']
        }
      ]
    }
  },
  videoUrl: 'https://c8.alamy.com/comp/CYDTE8/conceptual-photo-of-man-sitting-at-his-desk-ready-for-job-interview-CYDTE8.jpg',
  thumbnailUrl: 'https://media.licdn.com/dms/image/v2/D5605AQHDuJtJv5QD5w/feedshare-thumbnail_720_1280/B56ZcXT_HaGQAw-/0/1748442808056?e=2147483647&v=beta&t=xgKedf1FfCbnqOFKlgNzngtnyCR-luYqhCTKhPZGe1s'
};