import { createClient } from '@supabase/supabase-js';
import { Meeting } from '../types';

// These would be environment variables in a real application
const supabaseUrl = process.env.VITE_SUPABASE_URL || 'your-supabase-url';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || 'your-supabase-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Database operations for Go-X platform
export const supabaseOperations = {
  // Fetch all meetings for a user
  async getMeetings(userId: string): Promise<Meeting[]> {
    const { data, error } = await supabase
      .from('meetings')
      .select(`
        *,
        participants(*),
        speaker_segments(*),
        audio_metrics(*),
        health_metrics(*),
        biometric_verification(*),
        hr_insights(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching meetings:', error);
      return [];
    }

    return data || [];
  },

  // Create a new meeting
  async createMeeting(meeting: Partial<Meeting>): Promise<Meeting | null> {
    const { data, error } = await supabase
      .from('meetings')
      .insert([meeting])
      .select()
      .single();

    if (error) {
      console.error('Error creating meeting:', error);
      return null;
    }

    return data;
  },

  // Update meeting analytics in real-time
  async updateMeetingAnalytics(meetingId: string, analytics: any): Promise<boolean> {
    const { error } = await supabase
      .from('meetings')
      .update({ 
        audio_metrics: analytics.audioMetrics,
        health_metrics: analytics.healthMetrics,
        updated_at: new Date().toISOString()
      })
      .eq('id', meetingId);

    if (error) {
      console.error('Error updating analytics:', error);
      return false;
    }

    return true;
  },

  // Subscribe to real-time analytics updates
  subscribeToMeetingUpdates(meetingId: string, callback: (payload: any) => void) {
    return supabase
      .channel(`meeting-${meetingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'meetings',
          filter: `id=eq.${meetingId}`
        },
        callback
      )
      .subscribe();
  },

  // Store biometric verification results
  async saveBiometricVerification(meetingId: string, verification: any): Promise<boolean> {
    const { error } = await supabase
      .from('biometric_verification')
      .upsert([
        {
          meeting_id: meetingId,
          ...verification,
          verified_at: new Date().toISOString()
        }
      ]);

    if (error) {
      console.error('Error saving biometric verification:', error);
      return false;
    }

    return true;
  },

  // Get user profile and preferences
  async getUserProfile(userId: string) {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }

    return data;
  }
};

// Example database schema for migrations
export const databaseSchema = `
-- Users table (using Supabase auth)
CREATE TABLE user_profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  full_name TEXT,
  company TEXT,
  role TEXT,
  preferences JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meetings table
CREATE TABLE meetings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES user_profiles(id) NOT NULL,
  title TEXT NOT NULL,
  type TEXT DEFAULT 'interview',
  status TEXT DEFAULT 'active',
  date DATE NOT NULL,
  time TIME NOT NULL,
  duration INTERVAL,
  video_url TEXT,
  thumbnail_url TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Participants table
CREATE TABLE participants (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT DEFAULT 'candidate',
  color TEXT DEFAULT '#10B981',
  percentage DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Speaker segments for diarization
CREATE TABLE speaker_segments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  speaker_id UUID REFERENCES participants(id) ON DELETE CASCADE,
  start_time INTEGER NOT NULL,
  end_time INTEGER NOT NULL,
  duration INTEGER NOT NULL,
  confidence DECIMAL(3,2) DEFAULT 0.95,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audio analytics
CREATE TABLE audio_metrics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  overall_score INTEGER DEFAULT 0,
  lip_sync INTEGER DEFAULT 0,
  engagement INTEGER DEFAULT 0,
  influence INTEGER DEFAULT 0,
  truthfulness INTEGER DEFAULT 0,
  bias INTEGER DEFAULT 0,
  sentiment INTEGER DEFAULT 0,
  speaking_rate INTEGER DEFAULT 0,
  filler_words TEXT[] DEFAULT '{}',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Health metrics
CREATE TABLE health_metrics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  heart_rate JSONB DEFAULT '{}',
  heart_rate_variability JSONB DEFAULT '{}',
  blood_pressure JSONB DEFAULT '{}',
  spo2 JSONB DEFAULT '{}',
  stress_index JSONB DEFAULT '{}',
  respiration JSONB DEFAULT '{}',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Biometric verification
CREATE TABLE biometric_verification (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  candidate_email TEXT NOT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  liveness_detection BOOLEAN DEFAULT FALSE,
  expression_analysis BOOLEAN DEFAULT FALSE,
  voice_pattern_match BOOLEAN DEFAULT FALSE,
  speech_pattern BOOLEAN DEFAULT FALSE,
  insights TEXT[] DEFAULT '{}',
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- HR insights
CREATE TABLE hr_insights (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  meeting_id UUID REFERENCES meetings(id) ON DELETE CASCADE,
  overall_score INTEGER DEFAULT 0,
  recommendation TEXT DEFAULT 'pending',
  technical_score JSONB DEFAULT '{}',
  insights JSONB DEFAULT '[]',
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE speaker_segments ENABLE ROW LEVEL SECURITY;
ALTER TABLE audio_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE biometric_verification ENABLE ROW LEVEL SECURITY;
ALTER TABLE hr_insights ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own profile" ON user_profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON user_profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can read own meetings" ON meetings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create meetings" ON meetings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own meetings" ON meetings FOR UPDATE USING (auth.uid() = user_id);
`;