export interface Speaker {
  id: string;
  name: string;
  color: string;
  percentage: number;
}

export interface SpeakerSegment {
  speaker: string;
  startTime: number;
  endTime: number;
  duration: number;
}

export interface AudioMetrics {
  overallScore: number;
  lipSync: number;
  engagement: number;
  influence: number;
  truthfulness: number;
  bias: number;
  sentiment: number;
  speakingRate: number;
  fillerWords: string[];
}

export interface HealthMetrics {
  heartRate: {
    value: number;
    unit: string;
    normalRange: string;
    trend: number[];
  };
  heartRateVariability: {
    value: number;
    unit: string;
    normalRange: string;
    trend: number[];
  };
  bloodPressure: {
    systolic: number;
    diastolic: number;
    unit: string;
    normalRange: string;
  };
  spO2: {
    value: number;
    unit: string;
    normalRange: string;
  };
  stressIndex: {
    value: number;
    normalRange: string;
  };
  respiration: {
    value: number;
    unit: string;
    normalRange: string;
  };
}

export interface BiometricVerification {
  candidateEmail: string;
  isVerified: boolean;
  verificationItems: {
    livenessDetection: boolean;
    expressionAnalysis: boolean;
    voicePatternMatch: boolean;
    speechPattern: boolean;
  };
  insights: string[];
}

export interface HRInsights {
  candidateAnalysis: {
    overallScore: number;
    recommendation: string;
    technicalScore: {
      value: number;
      maxValue: number;
      rating: string;
    };
    insights: Array<{
      text: string;
      tags: string[];
    }>;
  };
}

export interface Meeting {
  id: string;
  title: string;
  date: string;
  time: string;
  duration: string;
  type: string;
  participants: Speaker[];
  speakerSegments: SpeakerSegment[];
  audioMetrics: AudioMetrics;
  healthMetrics: HealthMetrics;
  biometricVerification: BiometricVerification;
  hrInsights: HRInsights;
  videoUrl: string;
  thumbnailUrl: string;
}