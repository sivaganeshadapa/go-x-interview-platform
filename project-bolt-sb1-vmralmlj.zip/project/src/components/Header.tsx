import React from 'react';
import { ArrowLeft, Download, Share } from 'lucide-react';
import { Meeting } from '../types';

interface HeaderProps {
  meeting: Meeting;
  onBack?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
}

const Header: React.FC<HeaderProps> = ({ meeting, onBack, onDownload, onShare }) => {
  return (
    <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        
        <div>
          <h1 className="text-xl font-semibold text-gray-900">{meeting.title}</h1>
          <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
            <span>{meeting.date} | {meeting.time}</span>
            <span>{meeting.duration}</span>
            <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs">
              {meeting.type}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <button 
          onClick={onDownload}
          className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Download size={16} />
          <span>Download</span>
        </button>
        
        <button 
          onClick={onShare}
          className="flex items-center space-x-2 px-4 py-2 bg-[#7C4DFF] text-white rounded-lg hover:bg-[#6B3FF0] transition-colors"
        >
          <Share size={16} />
          <span>Share</span>
        </button>
      </div>
    </div>
  );
};

export default Header;