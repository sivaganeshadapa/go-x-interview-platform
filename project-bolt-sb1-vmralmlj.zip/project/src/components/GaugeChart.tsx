import React from 'react';

interface GaugeChartProps {
  value: number;
  maxValue?: number;
  size?: number;
  thickness?: number;
  showText?: boolean;
  colors?: string[];
}

const GaugeChart: React.FC<GaugeChartProps> = ({ 
  value, 
  maxValue = 100, 
  size = 120, 
  thickness = 12,
  showText = true,
  colors = ['#EF4444', '#F59E0B', '#10B981'] 
}) => {
  const normalizedValue = Math.min(Math.max(value, 0), maxValue);
  const percentage = (normalizedValue / maxValue) * 100;
  const angle = (percentage / 100) * 180; // Half circle
  
  const centerX = size / 2;
  const centerY = size / 2;
  const radius = (size - thickness) / 2;
  
  // Create gradient colors
  const getColor = (percent: number) => {
    if (percent < 33) return colors[0]; // Red
    if (percent < 66) return colors[1]; // Yellow
    return colors[2]; // Green
  };

  const strokeDasharray = Math.PI * radius; // Half circle circumference
  const strokeDashoffset = strokeDasharray - (strokeDasharray * percentage) / 100;

  return (
    <div className="relative flex items-center justify-center">
      <svg width={size} height={size / 2 + 20} className="transform -rotate-90">
        {/* Background arc */}
        <path
          d={`M ${thickness/2} ${centerY} A ${radius} ${radius} 0 0 1 ${size - thickness/2} ${centerY}`}
          fill="none"
          stroke="#E5E7EB"
          strokeWidth={thickness}
          strokeLinecap="round"
        />
        
        {/* Progress arc */}
        <path
          d={`M ${thickness/2} ${centerY} A ${radius} ${radius} 0 0 1 ${size - thickness/2} ${centerY}`}
          fill="none"
          stroke={getColor(percentage)}
          strokeWidth={thickness}
          strokeLinecap="round"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      
      {showText && (
        <div className="absolute inset-0 flex flex-col items-center justify-center mt-4">
          <span className="text-2xl font-bold text-gray-900">{value}%</span>
          <div className="flex items-center text-xs text-gray-500 mt-1">
            <span>0%</span>
            <span className="mx-8">100%</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default GaugeChart;