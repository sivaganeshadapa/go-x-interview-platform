import React, { useState } from 'react';
import { X, Minimize2, Maximize2, RotateCcw } from 'lucide-react';

interface VideoPlayerProps {
  mainVideoUrl: string;
  thumbnailUrl: string;
  candidateName: string;
  interviewer: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ 
  mainVideoUrl, 
  thumbnailUrl, 
  candidateName,
  interviewer 
}) => {
  const [showThumbnail, setShowThumbnail] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [mainVideo, setMainVideo] = useState({
    url: mainVideoUrl,
    name: candidateName
  });
  const [thumbnailVideo, setThumbnailVideo] = useState({
    url: thumbnailUrl,
    name: interviewer
  });

  const handleSwapVideos = () => {
    const tempMain = { ...mainVideo };
    setMainVideo(thumbnailVideo);
    setThumbnailVideo(tempMain);
  };

  const handleMinimize = () => {
    setIsMinimized(true);
    setIsMaximized(false);
  };

  const handleMaximize = () => {
    setIsMaximized(true);
    setIsMinimized(false);
  };

  const handleNormalSize = () => {
    setIsMinimized(false);
    setIsMaximized(false);
  };

  // Dynamic sizing classes
  const getVideoContainerClasses = () => {
    if (isMaximized) {
      return "relative bg-gray-100 rounded-lg overflow-hidden w-full h-96";
    } else if (isMinimized) {
      return "relative bg-gray-100 rounded-lg overflow-hidden w-80 h-48";
    } else {
      // Default reduced size for better analytics visibility
      return "relative bg-gray-100 rounded-lg overflow-hidden w-96 h-56";
    }
  };

  return (
    <div className="space-y-4">
      {/* Video Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-semibold text-gray-900">Interview Video</h3>
          <span className="text-sm text-gray-500">
            Main: {mainVideo.name} | Thumbnail: {thumbnailVideo.name}
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={handleSwapVideos}
            className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            title="Swap main and thumbnail videos"
          >
            <RotateCcw size={16} className="text-gray-600" />
          </button>
          
          <button
            onClick={handleMinimize}
            className={`p-2 rounded-lg transition-colors ${
              isMinimized ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
            }`}
            title="Minimize video"
          >
            <Minimize2 size={16} />
          </button>
          
          <button
            onClick={handleMaximize}
            className={`p-2 rounded-lg transition-colors ${
              isMaximized ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
            }`}
            title="Maximize video"
          >
            <Maximize2 size={16} />
          </button>
          
          {(isMinimized || isMaximized) && (
            <button
              onClick={handleNormalSize}
              className="px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded text-sm text-gray-600 transition-colors"
              title="Normal size"
            >
              Normal
            </button>
          )}
        </div>
      </div>

      {/* Video Container */}
      <div className={getVideoContainerClasses()}>
        {/* Main Video */}
        <img 
          src={mainVideo.url}
          alt={`${mainVideo.name} interview video`}
          className="w-full h-full object-cover"
        />

        {/* Floating Thumbnail */}
        {showThumbnail && (
          <div 
            className="absolute bottom-4 right-4 w-24 h-18 bg-white rounded-lg shadow-lg overflow-hidden border-2 border-white group cursor-pointer hover:scale-105 transition-transform"
            style={{ aspectRatio: '4/3' }}
            onClick={handleSwapVideos}
            title={`Click to swap with ${thumbnailVideo.name}`}
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowThumbnail(false);
              }}
              className="absolute top-1 right-1 w-4 h-4 bg-black bg-opacity-50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
              aria-label="Close thumbnail"
            >
              <X size={8} className="text-white" />
            </button>
            <img 
              src={thumbnailVideo.url}
              alt={thumbnailVideo.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs px-1 py-0.5 text-center">
              {thumbnailVideo.name}
            </div>
          </div>
        )}

        {/* Video Status Overlay */}
        <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs flex items-center space-x-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <span>Live Recording</span>
        </div>

        {/* Video Info Overlay */}
        <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
          {mainVideo.name} - Main View
        </div>

        {/* Size Indicator */}
        <div className="absolute top-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
          {isMaximized ? 'Maximized' : isMinimized ? 'Minimized' : 'Normal'}
        </div>
      </div>

      {/* Restore Thumbnail Button */}
      {!showThumbnail && (
        <button
          onClick={() => setShowThumbnail(true)}
          className="px-3 py-1 bg-blue-100 text-blue-600 rounded-lg text-sm hover:bg-blue-200 transition-colors"
        >
          Show {thumbnailVideo.name} Thumbnail
        </button>
      )}

      {/* Video Stats */}
      <div className="flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center space-x-4">
          <span>Duration: 20:00</span>
          <span>Quality: HD 1080p</span>
          <span>FPS: 30</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>Connection: Stable</span>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;