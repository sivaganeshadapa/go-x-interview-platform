import React from 'react';
import { Home, Video, Play, BarChart3, Heart, Settings, User } from 'lucide-react';

interface SidebarProps {
  activeItem?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeItem = 'meetings' }) => {
  const menuItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'meetings', icon: Video, label: 'Meetings' },
    { id: 'recordings', icon: Play, label: 'Recordings' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'health', icon: Heart, label: 'Health' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="w-16 bg-[#1B1F3B] h-screen flex flex-col items-center py-6 fixed left-0 top-0 z-40">
      {/* Logo */}
      <div className="mb-8">
        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
          <span className="text-[#1B1F3B] font-bold text-sm">Go X</span>
        </div>
      </div>

      {/* Navigation Items */}
      <nav className="flex flex-col space-y-4 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.id === activeItem;
          
          return (
            <button
              key={item.id}
              className={`p-3 rounded-lg transition-colors duration-200 ${
                isActive 
                  ? 'bg-[#7C4DFF] text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-[#2A2F4A]'
              }`}
              aria-label={item.label}
            >
              <Icon size={20} />
            </button>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="mt-auto">
        <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
          <User size={16} className="text-white" />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;