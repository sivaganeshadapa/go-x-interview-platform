import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import VideoPlayer from './VideoPlayer';
import SpeakerDiarization from './SpeakerDiarization';
import AnalyticsPanel from './AnalyticsPanel';
import { mockMeeting } from '../data/mockData';

const InterviewDashboard: React.FC = () => {
  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar + Main */}
      <Sidebar className="fixed left-0 top-0 h-screen w-16 z-40" />
      
      {/* Main zone */}
      <main className="flex-1 flex flex-col min-w-0 ml-16">
        {/* Header at top */}
        <Header meeting={mockMeeting} />
        
        {/* Content area */}
        <div className="flex flex-1 min-h-0 flex-col md:flex-row gap-2 p-2">
          {/* Left panel (video+timeline) */}
          <section className="flex flex-col flex-1 max-w-xs min-w-[260px] rounded-lg bg-white shadow">
            <VideoPlayer className="w-full aspect-video min-h-[140px] max-h-[210px]" />
            <SpeakerDiarization meeting={mockMeeting} />
          </section>
          
          {/* Right panel (analytics) */}
          <section className="flex-2 min-w-0 rounded-lg bg-white shadow p-4 overflow-y-auto">
            <AnalyticsPanel meeting={mockMeeting} />
          </section>
        </div>
      </main>
    </div>
  );
};

export default InterviewDashboard;