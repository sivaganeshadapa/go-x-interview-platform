import React from 'react';
import { AudioMetrics } from '../../types';
import GaugeChart from '../GaugeChart';

interface AudioAnalyticsProps {
  metrics: AudioMetrics;
}

const AudioAnalytics: React.FC<AudioAnalyticsProps> = ({ metrics }) => {
  const metricCards = [
    { label: 'Lip Sync', value: metrics.lipSync, icon: '👄', color: 'text-purple-600' },
    { label: 'Engagement', value: metrics.engagement, icon: '💬', color: 'text-blue-600' },
    { label: 'Influence', value: metrics.influence, icon: '⭐', color: 'text-yellow-600' },
    { label: 'Truthfulness', value: metrics.truthfulness, icon: '✓', color: 'text-green-600' },
    { label: 'Bias', value: metrics.bias, icon: '⚖️', color: 'text-red-600' },
    { label: 'Sentiment', value: metrics.sentiment, icon: '😊', color: 'text-pink-600' },
  ];

  return (
    <div className="space-y-6">
      {/* Overall Score */}
      <div className="bg-white rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Overall Score</h3>
        <div className="flex justify-center">
          <GaugeChart value={metrics.overallScore} />
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-4">
        {metricCards.map((metric) => (
          <div key={metric.label} className="bg-white rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className={`text-2xl ${metric.color}`}>{metric.icon}</span>
              <span className="text-lg font-semibold text-gray-900">{metric.value}%</span>
            </div>
            <h4 className="text-sm font-medium text-gray-700">{metric.label}</h4>
            <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${metric.value}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Speaking Rate */}
      <div className="bg-white rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Speaking Rate</h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Normal</span>
            <span className="w-3 h-3 bg-green-500 rounded-full"></span>
          </div>
        </div>
        
        <div className="relative">
          <div className="w-full h-4 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 rounded-full"></div>
          <div 
            className="absolute top-0 w-8 h-8 bg-white border-4 border-purple-600 rounded-full -mt-2 flex items-center justify-center shadow-lg"
            style={{ left: '60%' }}
          >
            <span className="text-xs font-bold text-purple-600">{metrics.speakingRate}</span>
          </div>
        </div>
      </div>

      {/* Filler Words */}
      <div className="bg-white rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filler Words</h3>
        <div className="flex flex-wrap gap-2">
          {metrics.fillerWords.map((word, index) => (
            <span 
              key={index}
              className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
            >
              {word}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AudioAnalytics;