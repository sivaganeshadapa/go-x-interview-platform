import React from 'react';
import { HRInsights as HRInsightsType } from '../../types';
import GaugeChart from '../GaugeChart';

interface HRInsightsProps {
  insights: HRInsightsType;
}

const HRInsights: React.FC<HRInsightsProps> = ({ insights }) => {
  const { candidateAnalysis } = insights;

  return (
    <div className="space-y-6">
      {/* Candidate Analysis Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Candidate Analysis</h3>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
          <span className="text-sm font-medium text-green-700 bg-green-100 px-3 py-1 rounded-full">
            {candidateAnalysis.recommendation}
          </span>
        </div>
      </div>

      {/* Overall Score */}
      <div className="bg-white rounded-lg p-6">
        <div className="flex justify-center mb-4">
          <GaugeChart value={candidateAnalysis.overallScore} />
        </div>
      </div>

      {/* Technical Score */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <div className="flex items-center justify-between mb-2">
          <h4 className="font-medium text-gray-900">Technical Score</h4>
          <span className="text-sm text-green-600 bg-green-100 px-2 py-1 rounded">
            {candidateAnalysis.technicalScore.rating}
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="flex items-center space-x-3">
          <div className="flex-1 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-[#7C4DFF] h-2 rounded-full transition-all duration-500"
              style={{ width: `${(candidateAnalysis.technicalScore.value / candidateAnalysis.technicalScore.maxValue) * 100}%` }}
            />
          </div>
          <span className="text-sm font-semibold text-gray-900">
            {candidateAnalysis.technicalScore.value}/{candidateAnalysis.technicalScore.maxValue}
          </span>
        </div>
      </div>

      {/* Zai Insights */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-4 h-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
          <h4 className="font-medium text-gray-900">Zai Insights</h4>
        </div>
        
        <div className="space-y-4">
          {candidateAnalysis.insights.map((insight, index) => (
            <div key={index} className="space-y-2">
              <p className="text-sm text-gray-700 leading-relaxed">• {insight.text}</p>
              <div className="flex flex-wrap gap-2 ml-4">
                {insight.tags.map((tag, tagIndex) => (
                  <span 
                    key={tagIndex}
                    className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HRInsights;