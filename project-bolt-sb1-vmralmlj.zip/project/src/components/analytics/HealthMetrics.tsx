import React from 'react';
import { HealthMetrics as HealthMetricsType } from '../../types';

interface HealthMetricsProps {
  metrics: HealthMetricsType;
}

const HealthMetrics: React.FC<HealthMetricsProps> = ({ metrics }) => {
  const healthCards = [
    {
      title: 'Heart Rate (HR)',
      value: metrics.heartRate.value,
      unit: metrics.heartRate.unit,
      normalRange: metrics.heartRate.normalRange,
      color: 'bg-red-500',
      trend: metrics.heartRate.trend
    },
    {
      title: 'Heart Rate Variability (HRV)',
      value: metrics.heartRateVariability.value,
      unit: metrics.heartRateVariability.unit,
      normalRange: metrics.heartRateVariability.normalRange,
      color: 'bg-blue-500',
      trend: metrics.heartRateVariability.trend
    },
    {
      title: 'Blood Pressure',
      value: `${metrics.bloodPressure.systolic} / ${metrics.bloodPressure.diastolic}`,
      unit: metrics.bloodPressure.unit,
      normalRange: metrics.bloodPressure.normalRange,
      color: 'bg-red-600'
    },
    {
      title: 'Blood Oxygen (SpO2)',
      value: metrics.spO2.value,
      unit: metrics.spO2.unit,
      normalRange: metrics.spO2.normalRange,
      color: 'bg-blue-600'
    },
    {
      title: 'Stress Index',
      value: metrics.stressIndex.value,
      unit: '',
      normalRange: metrics.stressIndex.normalRange,
      color: 'bg-yellow-500'
    },
    {
      title: 'Respiration',
      value: metrics.respiration.value,
      unit: metrics.respiration.unit,
      normalRange: metrics.respiration.normalRange,
      color: 'bg-green-500'
    }
  ];

  const Sparkline: React.FC<{ data: number[] }> = ({ data }) => {
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;
    
    return (
      <svg width="60" height="20" className="mt-2">
        <polyline
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          points={data.map((value, index) => {
            const x = (index / (data.length - 1)) * 58 + 1;
            const y = range === 0 ? 10 : 19 - ((value - min) / range) * 18;
            return `${x},${y}`;
          }).join(' ')}
        />
      </svg>
    );
  };

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-3">
          <div className="w-5 h-5 text-blue-600 mt-0.5">ℹ️</div>
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">Physiological Analytics</p>
            <p>The results below are estimated with up to 90% accuracy but may vary. Please consult a medical professional for validation.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {healthCards.map((card, index) => (
          <div key={index} className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="flex items-start justify-between mb-2">
              <div className={`w-6 h-6 ${card.color} rounded`}></div>
              <div className="text-right">
                <div className="text-lg font-semibold text-gray-900">
                  {card.value} <span className="text-sm font-normal text-gray-600">{card.unit}</span>
                </div>
                {card.trend && (
                  <div className="text-blue-500">
                    <Sparkline data={card.trend} />
                  </div>
                )}
              </div>
            </div>
            
            <h4 className="font-medium text-gray-900 text-sm mb-1">{card.title}</h4>
            <p className="text-xs text-gray-500">Normal range {card.normalRange}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-between items-center mt-6">
        <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors">
          Stop
        </button>
        <span className="text-sm text-purple-600 font-medium">Analyzing...</span>
      </div>
    </div>
  );
};

export default HealthMetrics;