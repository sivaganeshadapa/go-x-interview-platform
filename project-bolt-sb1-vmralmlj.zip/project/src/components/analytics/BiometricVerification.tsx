import React, { useState } from 'react';
import { BiometricVerification as BiometricVerificationType } from '../../types';
import { CheckCircle, Play } from 'lucide-react';

interface BiometricVerificationProps {
  data: BiometricVerificationType;
}

const BiometricVerification: React.FC<BiometricVerificationProps> = ({ data }) => {
  const [email, setEmail] = useState(data.candidateEmail);
  const [isPlaying, setIsPlaying] = useState(false);

  const verificationItems = [
    { 
      key: 'livenessDetection' as keyof typeof data.verificationItems, 
      label: 'Liveness Detection',
      completed: data.verificationItems.livenessDetection 
    },
    { 
      key: 'voicePatternMatch' as keyof typeof data.verificationItems, 
      label: 'Voice Pattern Match',
      completed: data.verificationItems.voicePatternMatch 
    },
    { 
      key: 'expressionAnalysis' as keyof typeof data.verificationItems, 
      label: 'Expression Analysis',
      completed: data.verificationItems.expressionAnalysis 
    },
    { 
      key: 'speechPattern' as keyof typeof data.verificationItems, 
      label: 'Speech Pattern',
      completed: data.verificationItems.speechPattern 
    },
  ];

  return (
    <div className="space-y-6">
      {/* Email Verification */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <div className="w-5 h-5 text-blue-600 mt-0.5">ℹ️</div>
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">Biometrics Verification</p>
            <p>Please enter candidate email to trigger biometric verification. Ensure the candidate is in the video before triggering.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg p-4">
        <div className="flex space-x-3">
          <input
            type="email"
            placeholder="Enter candidate email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
          <button className="px-4 py-2 bg-[#7C4DFF] text-white rounded-lg text-sm font-medium hover:bg-[#6B3FF0] transition-colors">
            Verify
          </button>
        </div>
      </div>

      {/* Verification Success */}
      {data.isVerified && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div className="text-sm text-green-800">
              <p className="font-medium">Candidate facial and voice biometrics are verified!</p>
              <p className="text-green-600">{data.candidateEmail}</p>
            </div>
          </div>
        </div>
      )}

      {/* Audio Waveform */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
            <img 
              src="https://c8.alamy.com/comp/CYDTE8/conceptual-photo-of-man-sitting-at-his-desk-ready-for-job-interview-CYDTE8.jpg" 
              alt="Candidate avatar"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 flex items-center space-x-3">
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-8 h-8 bg-[#7C4DFF] rounded-full flex items-center justify-center text-white hover:bg-[#6B3FF0] transition-colors"
            >
              <Play size={14} />
            </button>
            
            {/* Waveform visualization */}
            <div className="flex-1 flex items-center space-x-1 h-6">
              {Array.from({ length: 40 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-1 bg-blue-400 rounded-full transition-all duration-150 ${
                    isPlaying && i < 20 ? 'animate-pulse' : ''
                  }`}
                  style={{ 
                    height: `${Math.random() * 20 + 8}px`,
                    opacity: isPlaying && i < 20 ? 1 : 0.6
                  }}
                />
              ))}
            </div>
            
            <CheckCircle className="w-5 h-5 text-green-500" />
          </div>
        </div>
      </div>

      {/* Verification Checklist */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <h4 className="font-medium text-gray-900 mb-4">Verification Checklist</h4>
        <div className="grid grid-cols-2 gap-3">
          {verificationItems.map((item) => (
            <div key={item.key} className="flex items-center space-x-3">
              <CheckCircle 
                className={`w-4 h-4 ${item.completed ? 'text-green-500' : 'text-gray-300'}`} 
              />
              <span className={`text-sm ${item.completed ? 'text-gray-900' : 'text-gray-500'}`}>
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Zai Insights */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <div className="flex items-center space-x-2 mb-3">
          <div className="w-4 h-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
          <h4 className="font-medium text-gray-900">Zai Insights</h4>
        </div>
        <ul className="space-y-2">
          {data.insights.map((insight, index) => (
            <li key={index} className="text-sm text-gray-700 flex items-start space-x-2">
              <span className="text-gray-400 mt-1">•</span>
              <span>{insight}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default BiometricVerification;