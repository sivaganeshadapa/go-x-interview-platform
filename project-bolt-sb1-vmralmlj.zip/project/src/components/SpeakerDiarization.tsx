import React, { useState } from 'react';
import { Speaker, SpeakerSegment } from '../types';

interface SpeakerDiarizationProps {
  speakers: Speaker[];
  segments: SpeakerSegment[];
  currentTime?: number;
  totalDuration?: number;
}

const SpeakerDiarization: React.FC<SpeakerDiarizationProps> = ({
  speakers,
  segments,
  currentTime = 600,
  totalDuration = 1200
}) => {
  const [activeTab, setActiveTab] = useState('Speaker Diarization');
  
  const tabs = ['Speaker Diarization', 'Notes', 'Clips', 'Action Items', 'Key Questions'];

  return (
    <div className="bg-white rounded-lg p-4">
      {/* Tabs */}
      <div className="flex space-x-6 mb-6 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pb-2 px-1 text-sm font-medium transition-colors relative ${
              activeTab === tab
                ? 'text-[#7C4DFF] border-b-2 border-[#7C4DFF]'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Speaker Timeline */}
      {activeTab === 'Speaker Diarization' && (
        <div className="space-y-4">
          {speakers.map((speaker) => (
            <div key={speaker.id} className="flex items-center space-x-4">
              {/* Speaker Info */}
              <div className="flex items-center space-x-2 w-24">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: speaker.color }}
                />
                <span className="text-sm font-medium text-gray-700">{speaker.name}</span>
                <button className="text-gray-400 hover:text-gray-600">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                    <path d="M3 6h6M6 3v6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                </button>
              </div>

              {/* Timeline */}
              <div className="flex-1 relative h-6 bg-gray-100 rounded">
                {segments
                  .filter(segment => segment.speaker === speaker.id)
                  .map((segment, index) => (
                    <div
                      key={index}
                      className="absolute h-full rounded"
                      style={{
                        backgroundColor: speaker.color,
                        left: `${(segment.startTime / totalDuration) * 100}%`,
                        width: `${(segment.duration / totalDuration) * 100}%`,
                      }}
                    />
                  ))}
              </div>

              {/* Percentage */}
              <div className="text-sm text-gray-600 w-16 text-right">
                {speaker.percentage.toFixed(1)}%
              </div>
            </div>
          ))}

          {/* Playhead */}
          <div className="relative">
            <div 
              className="absolute top-0 w-0.5 h-16 bg-[#7C4DFF] -translate-y-16"
              style={{ left: `${(currentTime / totalDuration) * 100}%` }}
            >
              <div className="absolute -top-2 -left-2 w-4 h-4 bg-[#7C4DFF] rounded-full border-2 border-white shadow" />
            </div>
          </div>
        </div>
      )}

      {/* Other tabs content */}
      {activeTab !== 'Speaker Diarization' && (
        <div className="space-y-4">
          {activeTab === 'Notes' && (
            <div className="space-y-3">
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                <div className="flex items-start space-x-2">
                  <span className="text-yellow-600 font-semibold text-sm">7:16 PM</span>
                  <p className="text-sm text-gray-700">Candidate shows strong understanding of UI/UX principles</p>
                </div>
              </div>
              <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
                <div className="flex items-start space-x-2">
                  <span className="text-blue-600 font-semibold text-sm">7:18 PM</span>
                  <p className="text-sm text-gray-700">Excellent communication skills demonstrated</p>
                </div>
              </div>
              <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded">
                <div className="flex items-start space-x-2">
                  <span className="text-green-600 font-semibold text-sm">7:22 PM</span>
                  <p className="text-sm text-gray-700">Strong technical knowledge in Figma and design tools</p>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'Clips' && (
            <div className="space-y-3">
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900">Key Response - Design Process</h4>
                  <span className="text-xs text-gray-500">2:30 - 3:45</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">"I always start with user research to understand the problem..."</p>
                <button className="text-purple-600 text-sm hover:text-purple-700">▶ Play Clip</button>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900">Technical Skills Discussion</h4>
                  <span className="text-xs text-gray-500">8:15 - 9:30</span>
                </div>
                <p className="text-sm text-gray-600 mb-3">"I'm proficient in Figma, Sketch, and Adobe Creative Suite..."</p>
                <button className="text-purple-600 text-sm hover:text-purple-700">▶ Play Clip</button>
              </div>
            </div>
          )}
          
          {activeTab === 'Action Items' && (
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <input type="checkbox" className="mt-1 rounded border-gray-300 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-900">Send portfolio review feedback</p>
                  <p className="text-xs text-gray-500">Due: Tomorrow</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <input type="checkbox" className="mt-1 rounded border-gray-300 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-900">Schedule technical round with design team</p>
                  <p className="text-xs text-gray-500">Due: This week</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <input type="checkbox" checked className="mt-1 rounded border-gray-300 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-500 line-through">Review candidate's design samples</p>
                  <p className="text-xs text-gray-400">Completed</p>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'Key Questions' && (
            <div className="space-y-4">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <h4 className="font-medium text-purple-900 mb-2">Q: Tell me about your design process</h4>
                <p className="text-sm text-purple-700">Strong response - mentioned user research, wireframing, prototyping, and testing phases</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">Q: How do you handle design feedback?</h4>
                <p className="text-sm text-blue-700">Excellent collaborative mindset - open to feedback and iteration</p>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-medium text-green-900 mb-2">Q: What's your experience with accessibility?</h4>
                <p className="text-sm text-green-700">Good understanding of WCAG guidelines and inclusive design principles</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SpeakerDiarization;