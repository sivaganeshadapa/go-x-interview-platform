import React from 'react';
import { 
  Play, 
  Shield, 
  Brain, 
  Zap, 
  CheckCircle, 
  Star,
  ArrowRight,
  Users,
  Globe,
  Heart
} from 'lucide-react';

const Homepage: React.FC = () => {
  const features = [
    {
      icon: <Heart className="w-6 h-6" />,
      title: 'Physiological Analytics',
      description: 'Real-time heart rate, HRV, stress levels, and biometric monitoring during interviews.'
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Fraud-Proof Biometrics',
      description: 'Advanced facial recognition, voice pattern matching, and liveness detection.'
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: 'Real-time HR Insights',
      description: 'AI-powered candidate analysis with behavioral and technical scoring.'
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'Seamless Integrations',
      description: 'Connect with existing HR systems, ATS, and video conferencing platforms.'
    },
    {
      icon: <CheckCircle className="w-6 h-6" />,
      title: 'Secure & Compliant',
      description: 'Enterprise-grade security with GDPR, HIPAA, and SOC2 compliance.'
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'AI-Powered Summaries',
      description: 'Automated interview summaries with key insights and recommendations.'
    }
  ];

  const competitors = [
    {
      name: 'Go-X',
      features: {
        'Physiological Analytics': true,
        'Real-time Biometrics': true,
        'AI Recruiter (Zai)': true,
        'Voice Pattern Analysis': true,
        'Emotion Recognition': true,
        'Multi-language Support': '130+ languages',
        'Compliance': 'GDPR, HIPAA, SOC2'
      }
    },
    {
      name: 'HireVue',
      features: {
        'Physiological Analytics': false,
        'Real-time Biometrics': false,
        'AI Recruiter (Zai)': false,
        'Voice Pattern Analysis': 'Limited',
        'Emotion Recognition': 'Basic',
        'Multi-language Support': '30+ languages',
        'Compliance': 'GDPR'
      }
    },
    {
      name: 'Talview',
      features: {
        'Physiological Analytics': false,
        'Real-time Biometrics': 'Basic',
        'AI Recruiter (Zai)': false,
        'Voice Pattern Analysis': true,
        'Emotion Recognition': false,
        'Multi-language Support': '50+ languages',
        'Compliance': 'GDPR, SOC2'
      }
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'VP of Talent, TechCorp',
      content: 'Go-X reduced our false positive rates by 85% and helped us identify top talent 3x faster.',
      rating: 5
    },
    {
      name: 'Michael Rodriguez',
      role: 'Head of Recruitment, FinanceFirst',
      content: 'The physiological analytics gave us insights we never had before. Game-changing technology.',
      rating: 5
    },
    {
      name: 'Dr. Amanda Foster',
      role: 'Chief Medical Officer, HealthPlus',
      content: 'The biometric verification ensures candidate authenticity while maintaining privacy compliance.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-[#1B1F3B] rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">Go X</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Go-X</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Pricing</a>
              <a href="#about" className="text-gray-600 hover:text-gray-900">About</a>
              <a href="#contact" className="text-gray-600 hover:text-gray-900">Contact</a>
            </nav>
            
            <div className="flex items-center space-x-4">
              <button className="text-gray-600 hover:text-gray-900">Sign In</button>
              <button className="bg-[#7C4DFF] text-white px-4 py-2 rounded-lg hover:bg-[#6B3FF0] transition-colors">
                Request Demo
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-20 pb-32 bg-gradient-to-br from-[#1B1F3B] via-[#2A2F4A] to-[#7C4DFF]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Catalyzing Conversational 
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400"> Growth</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-lg">
                Go-X revolutionizes hiring with physiological analytics, real-time biometrics, 
                and Zai - your empathetic AI recruiter with 130+ language support.
              </p>
              <div className="flex items-center space-x-4">
                <button className="bg-[#00C2A0] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#00B395] transition-colors flex items-center space-x-2">
                  <span>Try Go-X Now</span>
                  <ArrowRight size={20} />
                </button>
                <button className="border border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-[#1B1F3B] transition-colors">
                  Request Demo
                </button>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white rounded-xl shadow-2xl p-4">
                <img 
                  src="https://tensorgo.com/wp-content/uploads/2024/10/Slide-16_9-31-1.png" 
                  alt="Go-X Interface"
                  className="w-full rounded-lg"
                />
                <div className="absolute -bottom-4 -right-4 bg-[#00C2A0] text-white p-3 rounded-lg shadow-lg">
                  <div className="text-sm font-semibold">Live Analytics</div>
                  <div className="text-xs opacity-90">98% Accuracy</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Go-X?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Advanced AI-powered interviewing platform with physiological insights 
              and behavioral analytics that competitors can't match.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
                <div className="w-12 h-12 bg-[#7C4DFF] bg-opacity-10 rounded-lg flex items-center justify-center text-[#7C4DFF] mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Go-X vs Competition
            </h2>
            <p className="text-xl text-gray-600">
              See how Go-X outperforms traditional interviewing platforms
            </p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-xl shadow-lg">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-6 font-semibold text-gray-900">Features</th>
                  {competitors.map((competitor) => (
                    <th key={competitor.name} className={`text-center p-6 font-semibold ${
                      competitor.name === 'Go-X' ? 'text-[#7C4DFF]' : 'text-gray-900'
                    }`}>
                      {competitor.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.keys(competitors[0].features).map((feature) => (
                  <tr key={feature} className="border-b border-gray-100">
                    <td className="p-6 font-medium text-gray-900">{feature}</td>
                    {competitors.map((competitor) => (
                      <td key={`${competitor.name}-${feature}`} className="p-6 text-center">
                        {typeof competitor.features[feature as keyof typeof competitor.features] === 'boolean' ? (
                          competitor.features[feature as keyof typeof competitor.features] ? (
                            <CheckCircle className={`w-5 h-5 mx-auto ${
                              competitor.name === 'Go-X' ? 'text-[#00C2A0]' : 'text-green-500'
                            }`} />
                          ) : (
                            <div className="w-5 h-5 mx-auto rounded-full bg-gray-300"></div>
                          )
                        ) : (
                          <span className={`text-sm ${
                            competitor.name === 'Go-X' ? 'text-[#7C4DFF] font-semibold' : 'text-gray-600'
                          }`}>
                            {competitor.features[feature as keyof typeof competitor.features]}
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Meet Zai Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-4xl font-bold mb-6">Meet Zai</h2>
              <p className="text-xl mb-6 text-purple-100">
                Your emotionally intelligent AI recruiter with 130+ languages, 
                adaptive empathy, and behavioral biometrics.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Globe className="w-5 h-5 text-purple-200" />
                  <span>130+ Languages supported</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Brain className="w-5 h-5 text-purple-200" />
                  <span>Adaptive empathy & emotional intelligence</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Heart className="w-5 h-5 text-purple-200" />
                  <span>Real-time behavioral biometrics</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-xl p-8 border border-white border-opacity-20">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Brain className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white text-center mb-4">Zai AI Assistant</h3>
                <p className="text-purple-100 text-center">
                  "I analyze micro-expressions, voice patterns, and physiological responses 
                  to provide unbiased candidate insights in real-time."
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Trusted by Industry Leaders
            </h2>
            <p className="text-xl text-gray-600">
              See what our customers say about transforming their hiring process
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.content}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-gray-600 text-sm">{testimonial.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#1B1F3B]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Hiring Process?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join industry leaders using Go-X to make better hiring decisions with AI-powered insights.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="bg-[#00C2A0] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#00B395] transition-colors flex items-center space-x-2">
              <span>Start Free Trial</span>
              <ArrowRight size={20} />
            </button>
            <button className="bg-[#7C4DFF] text-white px-6 py-3 rounded-lg shadow-2xl hover:bg-[#6B3FF0] transition-all duration-300 transform hover:scale-105 font-semibold text-lg border-2 border-white animate-pulse">
              🚀 View Dashboard Demo
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-[#7C4DFF] rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">Go X</span>
                </div>
                <span className="text-xl font-bold">Go-X</span>
              </div>
              <p className="text-gray-400">
                Revolutionizing hiring with AI-powered physiological analytics and biometric verification.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">GDPR Compliance</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-400">© 2025 Go-X. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-gray-400">Trusted by Fortune 500 companies</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;